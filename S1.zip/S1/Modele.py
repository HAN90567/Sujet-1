#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 23:45:13 2023

@author: etudiant
"""

# SUJET1 Modele.py

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam



def creer_modele(input_shape):
    model = Sequential([
        Dense(units=32, activation='relu', input_shape=(input_shape,)),
        Dense(units=16, activation='relu'),
        Dense(units=1, activation='sigmoid')
    ])

    model.compile(optimizer=Adam(learning_rate=0.001), loss='binary_crossentropy', metrics=['accuracy'])

    return model
