#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 29 23:45:38 2023

@author: etudiant
"""

# SUJET 1 EntraineEval.py

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import make_column_transformer
from sklearn.metrics import confusion_matrix
from Modele import creer_modele  # Assurez-vous que le nom du fichier est correct

# Lire le fichier CSV et supprimer la colonne 'id'
df = pd.read_csv('AVCdata.csv')
df = df.drop('id', axis=1)

# Supprimer les lignes contenant des valeurs NaN
df = df.dropna()

# Séparer les données et les cibles
data = df.drop('stroke', axis=1)
target = df['stroke']

# Diviser les données en ensembles d'entraînement et de test
X_train, X_test, y_train, y_test = train_test_split(data, target, test_size=0.2, random_state=42)

# Créer un pipeline pour encoder les colonnes en une seule colonne numérique
column_transformer = make_column_transformer(
    (StandardScaler(), ['age', 'hypertension', 'heart_disease', 'avg_glucose_level', 'bmi']),
    (OneHotEncoder(handle_unknown='ignore'), ['gender', 'ever_married', 'work_type', 'Residence_type', 'smoking_status']))

# Appliquer le pipeline à l'ensemble d'entraînement
X_train_transformed = column_transformer.fit_transform(X_train)

# Appliquer le même pipeline à l'ensemble de test sans ajustement
X_test_transformed = column_transformer.transform(X_test)

# Créer le modèle en utilisant la fonction creer_modele de Modele.py
modele = creer_modele(input_shape=(X_train_transformed.shape[1]))

# Entraîner le modèle
modele.fit(X_train_transformed, y_train, epochs=20, batch_size=32, validation_split=0.2)

# Sauvegarder le modèle
modele.save('reseau1')

# Prédiction sur l'ensemble de test 
y_pred = (modele.predict(X_test_transformed) > 0.5)

# Matrice de confusion
conf_matrix = confusion_matrix(y_test, y_pred)
print("Matrice de confusion:\n", conf_matrix)
